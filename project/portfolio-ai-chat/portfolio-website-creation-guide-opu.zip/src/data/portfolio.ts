// ============================================================
//  👉 EDITA TODO TU CONTENIDO AQUÍ. Es el único archivo que
//     necesitas cambiar para personalizar tu portafolio.
// ============================================================

export const profile = {
  nombre: "Tu Nombre Apellido",
  rol: "Desarrollador / Diseñador", // Tu título profesional
  ubicacion: "Ciudad, País",
  email: "tucorreo@ejemplo.com",
  telefono: "+00 000 000 000",
  disponible: true, // muestra un badge "Disponible para trabajar"
  // Texto corto para el hero (1-2 frases que te definan)
  tagline:
    "Construyo experiencias web modernas, rápidas y accesibles. Apasionado por el detalle y por resolver problemas reales con código.",
  // Descripción larga para la sección "Sobre mí"
  sobreMi:
    "Soy un profesional orientado a resultados con experiencia en el desarrollo de aplicaciones web y soluciones digitales. Me gusta trabajar en equipo, aprender constantemente y transformar ideas en productos funcionales. Busco oportunidades donde pueda aportar valor y seguir creciendo.",
  fotoUrl: "", // opcional: pon una URL o deja "" para usar iniciales
  cvUrl: "", // opcional: enlace a tu CV en PDF (ej: /cv.pdf)
};

export const social = {
  github: "https://github.com/tuusuario",
  linkedin: "https://linkedin.com/in/tuusuario",
  twitter: "", // deja "" para ocultar
  website: "",
};

// ============================================================
//  🤖 Asistente virtual (chatbot) que responde preguntas
//     sobre tu perfil profesional a quien visite el sitio.
// ============================================================
export const assistant = {
  nombre: "Nova", // el nombre de tu asistente virtual
  avatarUrl: "/images/assistant-avatar.png",
  mensajeBienvenida:
    "¡Hola! 👋 Soy Nova, la asistente virtual de {nombre}. Puedo contarte sobre su experiencia, proyectos, habilidades o cómo contactarlo. ¿Qué te gustaría saber?",
  sugerencias: [
    "¿Qué experiencia tiene?",
    "Cuéntame sobre sus proyectos",
    "¿Qué tecnologías domina?",
    "¿Cómo puedo contactarlo?",
    "¿Está disponible para trabajar?",
  ],
};

export type Skill = { nombre: string; nivel: number }; // nivel 0-100

export const skillGroups: { categoria: string; skills: Skill[] }[] = [
  {
    categoria: "Frontend",
    skills: [
      { nombre: "React", nivel: 90 },
      { nombre: "TypeScript", nivel: 85 },
      { nombre: "Tailwind CSS", nivel: 88 },
      { nombre: "HTML & CSS", nivel: 92 },
    ],
  },
  {
    categoria: "Backend",
    skills: [
      { nombre: "Node.js", nivel: 80 },
      { nombre: "Python", nivel: 75 },
      { nombre: "SQL / Bases de datos", nivel: 78 },
      { nombre: "APIs REST", nivel: 82 },
    ],
  },
  {
    categoria: "Herramientas",
    skills: [
      { nombre: "Git & GitHub", nivel: 85 },
      { nombre: "Figma", nivel: 70 },
      { nombre: "Docker", nivel: 60 },
      { nombre: "Linux", nivel: 72 },
    ],
  },
];

export type Project = {
  titulo: string;
  descripcion: string;
  tags: string[];
  imagen?: string; // URL de imagen o emoji
  demo?: string; // enlace a la demo en vivo
  codigo?: string; // enlace al repositorio
  destacado?: boolean;
};

export const projects: Project[] = [
  {
    titulo: "Plataforma E-commerce",
    descripcion:
      "Tienda online completa con carrito, pasarela de pago y panel de administración. Optimizada para móvil y con excelente rendimiento.",
    tags: ["React", "Node.js", "Stripe", "MongoDB"],
    imagen: "🛒",
    demo: "#",
    codigo: "#",
    destacado: true,
  },
  {
    titulo: "App de Gestión de Tareas",
    descripcion:
      "Aplicación tipo Kanban con arrastrar y soltar, autenticación de usuarios y sincronización en tiempo real.",
    tags: ["React", "TypeScript", "Firebase"],
    imagen: "✅",
    demo: "#",
    codigo: "#",
    destacado: true,
  },
  {
    titulo: "Dashboard de Analíticas",
    descripcion:
      "Panel de control con gráficos interactivos para visualizar métricas de negocio en tiempo real.",
    tags: ["React", "Chart.js", "REST API"],
    imagen: "📊",
    demo: "#",
    codigo: "#",
  },
  {
    titulo: "Landing Page Corporativa",
    descripcion:
      "Sitio web responsivo para una empresa, con animaciones suaves y formulario de contacto.",
    tags: ["HTML", "CSS", "JavaScript"],
    imagen: "🌐",
    demo: "#",
    codigo: "#",
  },
];

export type Experience = {
  puesto: string;
  empresa: string;
  periodo: string;
  descripcion: string;
  tipo: "trabajo" | "educacion";
};

export const experience: Experience[] = [
  {
    puesto: "Desarrollador Frontend",
    empresa: "Empresa Ejemplo S.A.",
    periodo: "2023 — Presente",
    descripcion:
      "Desarrollo y mantenimiento de interfaces web. Colaboración con equipos de diseño y backend para entregar funcionalidades de calidad.",
    tipo: "trabajo",
  },
  {
    puesto: "Desarrollador Junior",
    empresa: "Startup Digital",
    periodo: "2021 — 2023",
    descripcion:
      "Implementación de nuevas funcionalidades, corrección de errores y participación en revisiones de código.",
    tipo: "trabajo",
  },
  {
    puesto: "Ingeniería / Técnico en Sistemas",
    empresa: "Universidad / Instituto",
    periodo: "2017 — 2021",
    descripcion:
      "Formación en fundamentos de programación, bases de datos, redes y desarrollo de software.",
    tipo: "educacion",
  },
];
